public class sortTesting {
    private static final int RUNS = 10;

    public static void RunTests(){
        int[] sizes = {1000,5000,10000,50000,75000,100000,500000};
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        for (int i = 0; i < sizes.length; i++){
            int size = sizes[i];
            String day = days[i];
            testDay(day, size);
        }

    }

    public static void testDay(String day, int size){

        int[] random = ListGenerators.generateRandomList(size);
        int[] sorted = ListGenerators.generateSortedList(size);
        int[] reversed = ListGenerators.generateReversedList(size);

        printRow(day, size, "Random", random);
        printRow(day, size, "Sorted", sorted);
        printRow(day, size, "Reversed", reversed);
        System.out.println();


    }

    private static void printRow(String day, int size, String type, int[] original) {
        long quickTime = averageTime(original, true);
        long hybridTime = averageTime(original, false);

        double quickSeconds = quickTime / 1000000000.0;
        double quickMilliseconds = quickTime / 1000000.0;

        double hybridSeconds = hybridTime / 1000000000.0;
        double hybridMilliseconds = hybridTime / 1000000.0;

        System.out.println(
            "On " + day + " (" + size + " items), when the quick sort algorithm is run 10 times, " +
            "the average completion time was " +
            quickSeconds + " seconds or " +
            quickMilliseconds + " ms when sorting a " + type + " list."
        );

        System.out.println(
            "On " + day + " (" + size + " items), when the hybrid sort algorithm is run 10 times, " +
            "the average completion time was " +
            hybridSeconds + " seconds or " +
            hybridMilliseconds + " ms when sorting a " + type + " list."
        );
    }

    private static long averageTime(int[] original, boolean useQuickSort) {

        long total = 0;

        for (int i = 0; i < RUNS; i++) {

            int[] copy = original.clone();

            long start = System.nanoTime();

            if (useQuickSort) {
                quicksort.quicksort(copy);
            } else {
                hybridSort.hybridSort(copy);
            }

            long end = System.nanoTime();

            total += (end - start);
        }

        return total / RUNS;
    }
}

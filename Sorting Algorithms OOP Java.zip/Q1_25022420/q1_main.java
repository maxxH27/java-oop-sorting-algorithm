public class q1_main {
    public static void main(String[] args) {
        sortTesting.RunTests();
    }
}

import java.util.*;

public class ListGenerators {

    public static int[] generateRandomList(int size){
        int[] randomList = new int[size];

        for (int i = 0; i < size; i++) {
            randomList[i] = i + 1;
        }

        Random rand = new Random();
        for (int i = size - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);

            // swap
            int temp = randomList[i];
            randomList[i] = randomList[j];
            randomList[j] = temp;
        }

        return randomList;
    }

    public static int[] generateSortedList(int size){
        int[] sortedList = new int[size];

        for (int i = 0; i < size; i++) {
            sortedList[i] = i + 1;
        }

        return sortedList;
    }

    public static int[] generateReversedList(int size){
        int[] reversedList = new int[size];

        for (int i = 0; i < size; i++) {
            reversedList[i] = size - i;
        }

        return reversedList;
    }
}
import java.util.*;

public class hybridSort {

    public static final int THRESHOLD = 50;

    public static void hybridSort(int[] array) {
        hybridSort(array, 0, array.length - 1);
    }


    public static void hybridSort(int[] array, int lowIndex, int highIndex){
        if (lowIndex >= highIndex){
            return;
        }

        if (highIndex - lowIndex < THRESHOLD) {
            insertionSort(array, lowIndex, highIndex);
            return;
        }
        
        int pivotIndex = new Random().nextInt(highIndex - lowIndex) + lowIndex;
        int pivot = array[pivotIndex];
        swap(array, pivotIndex, highIndex);
        int leftPointer = lowIndex;
        int rightPointer = highIndex;
        while (leftPointer < rightPointer) {
            while (array[leftPointer] <= pivot && leftPointer < rightPointer) {
                leftPointer++;
            }

            while (array[rightPointer] >= pivot && leftPointer < rightPointer) {
                rightPointer--;
            }

            swap(array, leftPointer, rightPointer);
        }
        
        swap(array, leftPointer, highIndex);

        hybridSort(array, lowIndex, leftPointer-1);
        hybridSort(array, leftPointer+1, highIndex); 

    }
    private static void swap(int[] array, int index1, int index2){
            int temp= array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

    private static void insertionSort(int[] inputArray, int low, int high) {
        for (int i = low + 1; i < high; i++) {
            int currentValue = inputArray[i];
            
            int j = i - 1;
            while (j >= 0 && inputArray[j] > currentValue) {
                inputArray[j+1] = inputArray[j];
                j--;
            }
            inputArray[j+1] = currentValue;
        }
    }
}
